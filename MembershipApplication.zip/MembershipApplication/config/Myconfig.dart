class Myconfig{
  static const String server = "http://10.144.151.141";
}